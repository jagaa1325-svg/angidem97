-- Багшийн нэвтэрсэн хэрэглэгчид responses-ийг унших эрх
ALTER TABLE public.responses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "allow_authenticated_read_responses" ON public.responses;

CREATE POLICY "allow_authenticated_read_responses"
ON public.responses
FOR SELECT
TO authenticated
USING (true);
